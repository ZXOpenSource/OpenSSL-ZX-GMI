

typedef struct name_funcs_st NAME_FUNCS;
DEFINE_STACK_OF(NAME_FUNCS)
DEFINE_LHASH_OF(OBJ_NAME);
typedef struct added_obj_st ADDED_OBJ;
DEFINE_LHASH_OF(ADDED_OBJ);
